# Lead Research — free public-web edition

Private GitHub Actions project for discovering and screening business prospects in the approved Russian/Belarusian niches. It uses the open-source `ddgs` search library and standard Python only; no paid TinyFish browser actions, paid enrichment, proxies, paid APIs, or auto-reload.

## What one run does

1. Re-checks the current accepted list with two independent exact-name website searches.
2. Keeps a lead only when both searches return usable results without a likely own domain, a public activity date within the last 150 days is found, and a public business contact is present.
3. If the accepted list falls below the target, discovers replacements and runs both website checks plus a public activity/contact search.
4. Keeps unqualified candidates separately for manual review; it does not pad the accepted list to 100.
5. Produces CSV, JSON, and HTML reports with evidence URLs and review reasons.

The score is a prioritization aid, not a probability of purchase. A search not finding a domain is not proof that no website exists. Human verification remains mandatory before outreach.

## Important messaging/activity limits

- Public Telegram/VK links may be found, but last-post/last-seen evidence is only recorded when a dated public result is present.
- WhatsApp last-seen/online status is not a public business data field and is not scraped. `whatsapp_link` is a convenience link derived from a public phone number, not confirmation that the number uses WhatsApp.
- The workflow never logs into social accounts, bypasses access controls, solves CAPTCHAs, or sends messages.
- It never creates demo websites. Demos are created only after the prospect shows interest, in line with the studio's sales process.

## Target profile

- Main market: major/high-purchasing-power Russian cities.
- Belarus: Minsk only, hard cap 5 accepted leads.
- Approved niches only: house construction; roofing; custom furniture; auto import; premium detailing/wrapping/PPF; windows/doors/glazing; ventilation/conditioning/heating; landscape design/site improvement.
- Prefer businesses without a full official website.
- No artificial quotas by niche. Quality is more important than filling 100 rows.
- Small-city exceptions require a later explicitly approved search and are not part of the default city list.

## Setup

1. Create a **private** GitHub repository named `lead-research`.
2. Upload the contents of this folder to the repository's default branch (the files must be at repository root, including `.github/workflows/nightly-leads.yml`).
3. Open **Actions** and enable workflows if prompted.
4. Run **Nightly lead research** manually with mode `run` and target `100` to test it.
5. Open the completed run and download its report artifact. The repo also stores `reports/latest.html`, `reports/latest.csv`, `reports/leads-master.csv`, `reports/candidate-pool.csv`, `reports/run-summary.json`, and review/rejection files.

## Schedule and limits

- Scheduled runs: 00:17 and 04:17 Europe/Minsk (GitHub cron uses UTC).
- GitHub Actions can delay scheduled jobs; start times are not guaranteed.
- A scheduled workflow is bounded, not an infinite background loop. It does not know when the user's PC is turned on. In the morning, run the workflow manually with mode `pause` to stop future scheduled searches; use `resume` to continue. A later manual `run` starts one bounded run.
- Each job has a 20-minute timeout and re-checks up to 100 existing leads twice. If a run hits its time limit or search throttling, review the run log and re-run later; incomplete verification is not treated as success.
- GitHub Free lists 2,000 Actions minutes/month for private repositories. Two 20-minute maximum jobs daily could use up to 1,200 minutes in a 30-day month; check current account usage in GitHub Billing. This project does not enable paid billing or automatic top-ups.

## Free usage

The workflow uses GitHub-hosted runners on the included GitHub Actions quota and public web-search endpoints through `ddgs`. Search endpoints can throttle or change behaviour. No paid tool is called by this code. `requirements.txt` pins the dependency.

## Manual review checklist

Before outreach, verify:

1. Company identity matches name, city, address and public phone.
2. No official domain/full website exists (check exact-name variants, Yandex/2GIS/Maps and social profiles).
3. Public activity is genuinely recent; inspect the date and original source, not just a search snippet.
4. Public contact details belong to the business.
5. No duplicate or previously contacted record exists.
6. The company fits an approved niche and is commercially presentable.

No automatic messages, financial operations, paid purchases, or demo builds are performed.
