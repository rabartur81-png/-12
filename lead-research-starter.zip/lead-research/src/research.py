from __future__ import annotations

import argparse
import csv
import html
import json
import os
import re
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
TZ = ZoneInfo("Europe/Minsk")

# High-value Russian business centres. Minsk is handled separately and capped at 5.
RUSSIAN_CITIES = [
    "Москва", "Санкт-Петербург", "Казань", "Екатеринбург", "Краснодар",
    "Новосибирск", "Тюмень", "Сочи", "Нижний Новгород", "Ростов-на-Дону",
    "Самара", "Уфа", "Пермь", "Воронеж", "Челябинск", "Красноярск",
    "Иркутск", "Хабаровск",
]

NICHES: dict[str, list[str]] = {
    "Строительство домов": ["строительство загородных домов под ключ", "строительная компания коттеджи дома"],
    "Кровля": ["кровельные работы монтаж кровли", "кровельная компания крыши"],
    "Мебель на заказ": ["мебель на заказ производство", "мебель по индивидуальным размерам"],
    "Автоимпорт": ["автоимпорт привоз автомобилей под заказ", "автомобили из Китая Кореи под заказ"],
    "Премиальный детейлинг / PPF": ["премиальный детейлинг PPF оклейка", "защитная полиуретановая пленка детейлинг студия"],
    "Окна / двери / остекление": ["панорамное остекление окна двери компания", "алюминиевые конструкции остекление"],
    "Вентиляция / кондиционирование / отопление": ["монтаж вентиляции кондиционирования отопления компания", "климатические системы монтаж"],
    "Ландшафт / благоустройство": ["ландшафтный дизайн благоустройство участков", "озеленение благоустройство территорий"],
}

DIRECTORY_DOMAINS = {
    "2gis.ru", "2gis.com", "yandex.ru", "google.com", "google.ru", "zoon.ru",
    "yell.ru", "flamp.ru", "orgpage.ru", "spravker.ru", "allbiz.ru", "avito.ru",
    "youla.ru", "blizko.ru", "pulscen.ru", "promportal.su", "farpost.ru",
    "vk.com", "t.me", "telegram.me", "instagram.com", "ok.ru", "facebook.com",
    "youtube.com", "rutube.ru", "dzen.ru", "max.ru", "2gis.kz",
}
SOCIAL_DOMAINS = {"vk.com", "t.me", "telegram.me", "instagram.com", "ok.ru", "facebook.com", "youtube.com", "rutube.ru", "dzen.ru", "max.ru"}
PHONE_RE = re.compile(r"(?<!\w)(?:\+7|8|\+375)\s*[\(\-]?\d{2,3}[\)\-]?\s*\d{2,3}[\s\-]?\d{2}[\s\-]?\d{2}(?!\w)")
EMAIL_RE = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I)
URL_RE = re.compile(r"https?://[^\s<>\]\[\)\}\,;]+", re.I)
DATE_PATTERNS = [
    re.compile(r"\b(20\d{2})-(\d{1,2})-(\d{1,2})\b"),
    re.compile(r"\b(\d{1,2})[./](\d{1,2})[./](20\d{2})\b"),
]

@dataclass
class Candidate:
    name: str
    city: str
    country: str
    niche: str
    source_title: str = ""
    source_url: str = ""
    source_snippet: str = ""
    source_domain: str = ""
    phone: str = ""
    email: str = ""
    telegram_url: str = ""
    vk_url: str = ""
    whatsapp_link: str = ""
    website_pass_1: str = "not_checked"
    website_pass_1_evidence: str = ""
    website_pass_2: str = "not_checked"
    website_pass_2_evidence: str = ""
    activity_date: str = ""
    activity_evidence: str = ""
    activity_status: str = "unknown"
    whatsapp_activity_status: str = "not_publicly_verifiable"
    status: str = "candidate"
    priority_score: int = 0
    confidence: str = "low"
    manual_review_required: bool = True
    review_reason: str = ""
    checked_at_utc: str = ""

    @property
    def key(self) -> str:
        return candidate_key(self.name, self.city)


def host(url: str) -> str:
    try:
        h = (urlparse(url).hostname or "").lower()
        return h[4:] if h.startswith("www.") else h
    except Exception:
        return ""


def is_subdomain_of(domain: str, parent: str) -> bool:
    return domain == parent or domain.endswith("." + parent)


def is_directory_or_social(domain: str) -> bool:
    return any(is_subdomain_of(domain, d) for d in DIRECTORY_DOMAINS)


def is_social(domain: str) -> bool:
    return any(is_subdomain_of(domain, d) for d in SOCIAL_DOMAINS)


def clean_title(title: str) -> str:
    title = re.sub(r"\s+[-|–—]\s+(2ГИС|Яндекс|Отзывы|Каталог|Справочник).*$", "", title, flags=re.I)
    title = re.sub(r"\s+[-|–—]\s+.*$", "", title)
    return re.sub(r"\s+", " ", title).strip(" \t-–—|·")[:180]


def candidate_key(name: str, city: str) -> str:
    norm = re.sub(r"[^a-zа-я0-9]+", "", (name or "").lower())
    return f"{norm}|{(city or '').lower()}"


def normalise_phone(phone: str) -> str:
    digits = re.sub(r"\D", "", phone or "")
    if digits.startswith("8") and len(digits) == 11:
        digits = "7" + digits[1:]
    return digits


def build_whatsapp_link(phone: str) -> str:
    digits = normalise_phone(phone)
    if len(digits) in (11, 12) and digits.startswith(("7", "375")):
        return f"https://wa.me/{digits}"
    return ""


def extract_dates(text: str, today: date | None = None) -> list[date]:
    found: list[date] = []
    base = today or datetime.now(TZ).date()
    source = text or ""
    for idx, pattern in enumerate(DATE_PATTERNS):
        for match in pattern.finditer(source):
            try:
                if idx == 0:
                    y, m, d = map(int, match.groups())
                else:
                    d, m, y = map(int, match.groups())
                found.append(date(y, m, d))
            except ValueError:
                continue
    low = source.lower()
    if "сегодня" in low:
        found.append(base)
    if "вчера" in low:
        found.append(base - timedelta(days=1))
    if "позавчера" in low:
        found.append(base - timedelta(days=2))
    relative_patterns = [
        (re.compile(r"\b(\d{1,2})\s+(?:дн(?:я|ей)?|день)\s+назад\b"), 1),
        (re.compile(r"\b(\d{1,2})\s+недел(?:ю|и|ь)\s+назад\b"), 7),
        (re.compile(r"\b(\d{1,2})\s+месяц(?:а|ев)?\s+назад\b"), 30),
    ]
    for pattern, multiplier in relative_patterns:
        for match in pattern.finditer(low):
            try:
                found.append(base - timedelta(days=int(match.group(1)) * multiplier))
            except (ValueError, OverflowError):
                pass
    return found


def extract_contacts(text: str, result_url: str = "") -> dict[str, str]:
    content = text or ""
    urls = URL_RE.findall(content)
    if result_url:
        urls.append(result_url)
    telegram = ""
    vk = ""
    for candidate_url in urls:
        cleaned_url = candidate_url.rstrip(".,;)")
        parsed_host = host(cleaned_url).rstrip("/")
        if not telegram and (is_subdomain_of(parsed_host, "t.me") or is_subdomain_of(parsed_host, "telegram.me")):
            telegram = cleaned_url
        if not vk and is_subdomain_of(parsed_host, "vk.com"):
            vk = cleaned_url
    phones = PHONE_RE.findall(content)
    emails = EMAIL_RE.findall(content)
    phone = phones[0].strip() if phones else ""
    return {
        "phone": phone,
        "email": emails[0] if emails else "",
        "telegram_url": telegram,
        "vk_url": vk,
        "whatsapp_link": build_whatsapp_link(phone),
    }


def search(ddgs: Any, query: str, max_results: int = 6) -> list[dict[str, Any]]:
    try:
        rows = ddgs.text(query, region="ru-ru", safesearch="moderate", max_results=max_results, backend="auto")
        return rows or []
    except Exception as exc:
        print(f"SEARCH_WARNING: {query!r}: {type(exc).__name__}: {exc}", file=sys.stderr)
        return []


def query_plan() -> list[tuple[str, str, str, str]]:
    plan: list[tuple[str, str, str, str]] = []
    for city_idx, city in enumerate(RUSSIAN_CITIES):
        for niche_idx, (niche, variants) in enumerate(NICHES.items()):
            variant = variants[(city_idx + niche_idx) % len(variants)]
            plan.append((city, "Россия", niche, f'"{variant}" "{city}" контакты отзывы'))
    for niche, variants in NICHES.items():
        plan.append(("Минск", "Беларусь", niche, f'"{variants[0]}" "Минск" контакты отзывы'))
    return plan


def title_is_noise(title: str, url: str) -> bool:
    low = (title + " " + url).lower()
    bad = ["вакансии", "работа в", "купить", "объявления", "форум", "топ-", "рейтинг лучших", "каталог компаний"]
    return any(x in low for x in bad)


def identity_mentioned(candidate: Candidate, title: str, snippet: str) -> bool:
    target = re.sub(r"[^a-zа-я0-9 ]+", " ", candidate.name.lower())
    hay = re.sub(r"[^a-zа-я0-9 ]+", " ", (title + " " + snippet).lower())
    tokens = [t for t in target.split() if len(t) >= 3]
    if not tokens:
        return False
    hits = sum(1 for t in tokens if t in hay)
    return hits / len(tokens) >= 0.5


def official_domains_in_results(candidate: Candidate, results: list[dict[str, Any]]) -> list[str]:
    found: list[str] = []
    for row in results:
        url = str(row.get("href", "") or "")
        domain = host(url)
        title = str(row.get("title", "") or "")
        snippet = str(row.get("body", "") or "")
        if not domain or is_directory_or_social(domain):
            continue
        if identity_mentioned(candidate, title, snippet):
            found.append(domain)
    return list(dict.fromkeys(found))


def discover(ddgs: Any, target_pool: int = 180) -> list[Candidate]:
    found: dict[str, Candidate] = {}
    plan = query_plan()
    print(f"Discovery queries planned: {len(plan)}")
    for idx, (city, country, niche, query) in enumerate(plan, 1):
        print(f"[discover {idx}/{len(plan)}] {query}")
        for row in search(ddgs, query, max_results=7):
            title = clean_title(str(row.get("title", "") or ""))
            url = str(row.get("href", "") or "")
            snippet = str(row.get("body", "") or "")
            domain = host(url)
            if not title or not url or title_is_noise(title, url):
                continue
            # Keep directory/social listings as candidate sources. A direct business domain
            # is evidence of an existing website and is not a no-site prospect.
            if domain and not is_directory_or_social(domain):
                continue
            candidate = Candidate(
                name=title, city=city, country=country, niche=niche,
                source_title=str(row.get("title", "") or ""), source_url=url,
                source_snippet=snippet[:1200], source_domain=domain,
            )
            candidate.__dict__.update(extract_contacts(snippet, url))
            key = candidate.key
            if not key.strip("|"):
                continue
            if key not in found:
                found[key] = candidate
            else:
                old = found[key]
                for field_name in ("phone", "email", "telegram_url", "vk_url", "whatsapp_link"):
                    if not getattr(old, field_name) and getattr(candidate, field_name):
                        setattr(old, field_name, getattr(candidate, field_name))
            if len(found) >= target_pool:
                return list(found.values())
        time.sleep(0.25)
    return list(found.values())


def verify_website_pass(ddgs: Any, candidate: Candidate, pass_no: int) -> None:
    if pass_no == 1:
        query = f'"{candidate.name}" "{candidate.city}" официальный сайт'
    else:
        query = f'"{candidate.name}" "{candidate.city}" контакты сайт компания'
    results = search(ddgs, query, max_results=6)
    domains = official_domains_in_results(candidate, results)
    evidence = [str(r.get("href", "")) for r in results if r.get("href")]
    if domains:
        status = "probable_official_site_found"
        evidence_text = "Домены: " + ", ".join(domains) + " | " + " | ".join(evidence[:5])
    elif results:
        status = "not_found_in_search"
        evidence_text = " | ".join(evidence[:6])
    else:
        status = "verification_failed"
        evidence_text = "Поиск не вернул пригодных результатов"
    if pass_no == 1:
        candidate.website_pass_1 = status
        candidate.website_pass_1_evidence = evidence_text
    else:
        candidate.website_pass_2 = status
        candidate.website_pass_2_evidence = evidence_text
    # Refill contact fields from public snippets when available.
    for row in results:
        contacts = extract_contacts(str(row.get("body", "") or ""), str(row.get("href", "") or ""))
        for field_name, value in contacts.items():
            if value and not getattr(candidate, field_name):
                setattr(candidate, field_name, value)


def verify_activity_and_social(ddgs: Any, candidate: Candidate) -> None:
    query = f'"{candidate.name}" "{candidate.city}" отзывы последние работы Telegram WhatsApp'
    results = search(ddgs, query, max_results=8)
    evidence_parts: list[str] = []
    dates: list[date] = []
    for row in results:
        title = str(row.get("title", "") or "")
        snippet = str(row.get("body", "") or "")
        url = str(row.get("href", "") or "")
        date_hint = str(row.get("date", "") or row.get("published", "") or row.get("published_date", ""))
        text = f"{title} {snippet} {date_hint}"
        evidence_parts.append(f"{url} — {snippet[:350]}")
        dates.extend(extract_dates(text))
        contacts = extract_contacts(snippet, url)
        for field_name, value in contacts.items():
            if value and not getattr(candidate, field_name):
                setattr(candidate, field_name, value)
    today = datetime.now(TZ).date()
    valid_dates = [d for d in dates if d <= today]
    if valid_dates:
        newest = max(valid_dates)
        candidate.activity_date = newest.isoformat()
        candidate.activity_evidence = " | ".join(evidence_parts[:5])[:2200]
        candidate.activity_status = "recent_public_date_found" if newest >= today - timedelta(days=150) else "old_public_date_found"
    else:
        candidate.activity_status = "no_explicit_public_activity_date_found"
        candidate.activity_evidence = " | ".join(evidence_parts[:5])[:2200]
    candidate.whatsapp_activity_status = "not_publicly_verifiable"
    if candidate.phone and not candidate.whatsapp_link:
        candidate.whatsapp_link = build_whatsapp_link(candidate.phone)


def score(candidate: Candidate) -> int:
    value = 35  # configured major city + approved niche
    if candidate.phone:
        value += 18
    if candidate.telegram_url:
        value += 10
    if candidate.vk_url:
        value += 5
    if candidate.email:
        value += 5
    if candidate.source_url:
        value += 8
    if candidate.website_pass_1 == "not_found_in_search" and candidate.website_pass_2 == "not_found_in_search":
        value += 12
    if candidate.activity_status == "recent_public_date_found":
        value += 7
    elif candidate.activity_status == "old_public_date_found":
        value -= 15
    return max(0, min(100, value))


def is_qualified(candidate: Candidate) -> bool:
    return (
        candidate.website_pass_1 == "not_found_in_search"
        and candidate.website_pass_2 == "not_found_in_search"
        and candidate.activity_status == "recent_public_date_found"
        and bool(candidate.phone or candidate.telegram_url or candidate.vk_url or candidate.email)
    )


def make_reason(candidate: Candidate) -> str:
    reasons = []
    if candidate.website_pass_1 != "not_found_in_search" or candidate.website_pass_2 != "not_found_in_search":
        reasons.append("Сайт не исключён двумя независимыми поисковыми проверками")
    if candidate.activity_status != "recent_public_date_found":
        reasons.append("Нет подтверждённой публичной активности за последние 150 дней")
    if not (candidate.phone or candidate.telegram_url or candidate.vk_url or candidate.email):
        reasons.append("Нет подтверждённого публичного контакта")
    if candidate.whatsapp_activity_status == "not_publicly_verifiable":
        reasons.append("Последняя активность WhatsApp не проверяется публично")
    return "; ".join(reasons) if reasons else "Два поисковых прохода не выявили собственного домена; найдена датированная публичная активность и контакт. Перед обращением нужна ручная проверка карточки компании."


def read_csv(path: Path) -> list[Candidate]:
    if not path.exists():
        return []
    rows: list[Candidate] = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            allowed = Candidate.__dataclass_fields__.keys()
            data = {k: row.get(k, "") for k in allowed}
            try:
                data["priority_score"] = int(data.get("priority_score") or 0)
            except (TypeError, ValueError):
                data["priority_score"] = 0
            data["manual_review_required"] = str(data.get("manual_review_required", "True")).lower() != "false"
            rows.append(Candidate(**data))
    return rows


def merge_candidates(*groups: list[Candidate]) -> list[Candidate]:
    merged: dict[str, Candidate] = {}
    for group in groups:
        for candidate in group:
            key = candidate.key
            if not key.strip("|"):
                continue
            if key not in merged:
                merged[key] = candidate
            else:
                old = merged[key]
                for field_name in ("phone", "email", "telegram_url", "vk_url", "whatsapp_link", "source_url", "source_snippet"):
                    if not getattr(old, field_name) and getattr(candidate, field_name):
                        setattr(old, field_name, getattr(candidate, field_name))
    return list(merged.values())


def write_csv(path: Path, candidates: list[Candidate], stamp: str) -> None:
    fields = list(Candidate.__dataclass_fields__.keys())
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for c in candidates:
            row = asdict(c)
            row["checked_at_utc"] = stamp
            writer.writerow(row)


def run(target: int, max_new_checks: int = 100) -> dict[str, Any]:
    from ddgs import DDGS

    master_path = REPORTS / "leads-master.csv"
    pool_path = REPORTS / "candidate-pool.csv"
    old_master = read_csv(master_path)
    old_pool = read_csv(pool_path)
    candidates = merge_candidates(old_master, old_pool)
    ddgs = DDGS(timeout=10)
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    rejected: list[Candidate] = []

    # Re-check every currently accepted lead twice on every scheduled cycle.
    print(f"Rechecking existing lead pool: {len(candidates)} candidates")
    for idx, c in enumerate(candidates, 1):
        print(f"[recheck {idx}/{len(candidates)}] {c.name} — {c.city}")
        verify_website_pass(ddgs, c, 1)
        time.sleep(0.2)
        verify_website_pass(ddgs, c, 2)
        verify_activity_and_social(ddgs, c)
        c.priority_score = score(c)
        c.status = "qualified" if is_qualified(c) else "needs_manual_review_or_replacement"
        c.review_reason = make_reason(c)
        c.checked_at_utc = timestamp
        time.sleep(0.2)

    qualified = [c for c in candidates if is_qualified(c)]
    rejected = [c for c in candidates if not is_qualified(c)]
    existing_keys = {c.key for c in candidates}

    # Discover replacements if the active qualified list is below target.
    need = max(0, target - len(qualified))
    reserve_target = 20
    reserve_need = max(0, reserve_target - len(old_pool))
    new_candidates: list[Candidate] = []
    if need or reserve_need:
        print(f"Qualified leads: {len(qualified)}. Replacements needed: {need}; reserve slots needed: {reserve_need}")
        discoveries = discover(ddgs, target_pool=max((need + reserve_need) * 5, 80))
        check_limit = min(max_new_checks, max(need * 5 + reserve_need * 2, 30))
        for cand in discoveries:
            if cand.key in existing_keys:
                continue
            existing_keys.add(cand.key)
            new_candidates.append(cand)
            if len(new_candidates) >= check_limit:
                break
        print(f"New candidates discovered: {len(new_candidates)}")
        for idx, c in enumerate(new_candidates, 1):
            print(f"[new candidate checks {idx}/{len(new_candidates)}] {c.name} — {c.city}")
            verify_website_pass(ddgs, c, 1)
            time.sleep(0.2)
            verify_website_pass(ddgs, c, 2)
            verify_activity_and_social(ddgs, c)
            c.priority_score = score(c)
            c.status = "qualified" if is_qualified(c) else "needs_manual_review_or_replacement"
            c.review_reason = make_reason(c)
            c.checked_at_utc = timestamp
            time.sleep(0.2)

    all_rows = merge_candidates(qualified, rejected, new_candidates)
    qualified = [c for c in all_rows if is_qualified(c)]
    manual_review = [c for c in all_rows if not is_qualified(c)]

    # Enforce max 5 Minsk and target 100. Quality ranking only; no niche quotas.
    russian = [c for c in qualified if c.country == "Россия"]
    minsk = [c for c in qualified if c.country == "Беларусь" and c.city == "Минск"][:5]
    russian.sort(key=lambda c: (c.priority_score, c.activity_date), reverse=True)
    final = (russian + minsk)[:target]

    # Keep a pool of candidates (including failed ones) so future runs can replace rejects.
    final_keys = {c.key for c in final}
    pool_kept = [c for c in all_rows if c.key not in final_keys
                 and c.website_pass_1 != "probable_official_site_found"
                 and c.website_pass_2 != "probable_official_site_found"]
    pool_kept.sort(key=lambda c: (is_qualified(c), c.priority_score, c.activity_date), reverse=True)

    write_csv(REPORTS / "leads-master.csv", final, timestamp)
    write_csv(REPORTS / "candidate-pool.csv", pool_kept[:40], timestamp)
    write_csv(REPORTS / "latest.csv", final, timestamp)
    write_csv(REPORTS / "manual-review.csv", pool_kept[:40], timestamp)
    write_csv(REPORTS / "rejected-this-run.csv", rejected, timestamp)
    write_csv(REPORTS / "new-this-run.csv", new_candidates, timestamp)

    summary = {
        "run_at_utc": timestamp,
        "target_count": target,
        "qualified_leads": len(final),
        "shortfall": max(0, target - len(final)),
        "russia_rows": sum(c.country == "Россия" for c in final),
        "minsk_rows": sum(c.city == "Минск" for c in final),
        "rechecked_existing": len(candidates),
        "new_candidates_checked": len(new_candidates),
        "replacement_reserve": len(pool_kept[:40]),
        "activity_rule": "A lead is counted only when an explicit public activity date within 150 days is found; unknown WhatsApp last-seen remains unverified.",
        "website_rule": "Two independent exact-name searches must not surface a likely official domain. This is still not mathematical proof that no website exists.",
        "warning": "Do not treat priority_score as purchase probability. Review source evidence manually before contacting. No messages were sent.",
    }
    (REPORTS / "run-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (REPORTS / "latest.html").write_text(render_html(final, pool_kept, summary), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def render_html(leads: list[Candidate], pool: list[Candidate], summary: dict[str, Any]) -> str:
    def row(c: Candidate) -> str:
        wa = f'<a href="{html.escape(c.whatsapp_link, quote=True)}" rel="noopener" target="_blank">WhatsApp (не подтверждён)</a>' if c.whatsapp_link else "—"
        tg = f'<a href="{html.escape(c.telegram_url, quote=True)}" rel="noopener" target="_blank">Telegram</a>' if c.telegram_url else "—"
        vk = f'<a href="{html.escape(c.vk_url, quote=True)}" rel="noopener" target="_blank">VK</a>' if c.vk_url else "—"
        src = f'<a href="{html.escape(c.source_url, quote=True)}" rel="noopener" target="_blank">Источник</a>' if c.source_url else "—"
        return "<tr>" + "".join([
            f"<td>{html.escape(c.name)}</td>", f"<td>{html.escape(c.city)}</td>", f"<td>{html.escape(c.niche)}</td>",
            f"<td>{c.priority_score}/100</td>", f"<td>{html.escape(c.website_pass_1)}<br>{html.escape(c.website_pass_2)}</td>",
            f"<td>{html.escape(c.activity_status)}<br>{html.escape(c.activity_date)}</td>",
            f"<td>{html.escape(c.phone)}<br>{html.escape(c.email)}</td>", f"<td>{tg}<br>{vk}<br>{wa}</td>",
            f"<td>{src}</td>", f"<td>{html.escape(c.review_reason)}</td>",
        ]) + "</tr>"
    lead_rows = "".join(row(c) for c in leads)
    pool_rows = "".join(row(c) for c in pool[:250])
    return f'''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Lead Research</title>
<style>body{{font:14px/1.5 system-ui,sans-serif;margin:22px;color:#202124}}h1{{margin-bottom:4px}}.note{{padding:12px;background:#fff3cd;border:1px solid #edd68c;border-radius:8px;margin:16px 0}}.stats{{display:flex;gap:10px;flex-wrap:wrap}}.stat{{padding:10px;border:1px solid #ddd;border-radius:8px}}table{{border-collapse:collapse;width:100%;margin:18px 0}}th,td{{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}}th{{background:#f4f5f6;position:sticky;top:0}}td{{max-width:320px;overflow-wrap:anywhere}}a{{color:#1558a6}}.muted{{color:#666}}</style></head><body>
<h1>Lead Research — проверенный список</h1><div class="muted">Запуск: {html.escape(summary['run_at_utc'])}</div>
<div class="note"><b>Важно:</b> официальный сайт проверяется двумя независимыми поисковыми запросами, но отсутствие результата не является абсолютным доказательством отсутствия сайта. WhatsApp last seen не является публично проверяемым полем. Публичная активность засчитывается только при найденной датированной записи/отзыве за последние 150 дней. Перед обращением проверь источник вручную. Автоматических сообщений нет.</div>
<div class="stats"><div class="stat">Подтверждено по правилам: {summary['qualified_leads']} / {summary['target_count']}</div><div class="stat">Россия: {summary['russia_rows']}</div><div class="stat">Минск: {summary['minsk_rows']} / 5</div><div class="stat">Повторно проверено: {summary['rechecked_existing']}</div><div class="stat">Новых кандидатов: {summary['new_candidates_checked']}</div><div class="stat">Резерв на ручную проверку: {summary['replacement_reserve']}</div></div>
<h2>Квалифицированные лиды</h2><table><thead><tr><th>Компания</th><th>Город</th><th>Ниша</th><th>Оценка</th><th>Проверка сайта 1/2</th><th>Активность</th><th>Контакты</th><th>Мессенджеры</th><th>Источник</th><th>Примечание</th></tr></thead><tbody>{lead_rows}</tbody></table>
<h2>Кандидаты, не прошедшие автоматическую квалификацию</h2><p class="muted">Не считать готовыми лидами; список нужен для ручной проверки или замены.</p><table><thead><tr><th>Компания</th><th>Город</th><th>Ниша</th><th>Оценка</th><th>Проверка сайта 1/2</th><th>Активность</th><th>Контакты</th><th>Мессенджеры</th><th>Источник</th><th>Причина</th></tr></thead><tbody>{pool_rows}</tbody></table></body></html>'''


def main() -> None:
    parser = argparse.ArgumentParser(description="Free public-web business lead research")
    parser.add_argument("--target", type=int, default=int(os.getenv("TARGET_COUNT", "100")))
    parser.add_argument("--max-new-checks", type=int, default=int(os.getenv("MAX_NEW_CHECKS", "100")))
    args = parser.parse_args()
    target = max(1, min(100, args.target))
    max_new_checks = max(1, min(150, args.max_new_checks))
    run(target, max_new_checks)


if __name__ == "__main__":
    main()
