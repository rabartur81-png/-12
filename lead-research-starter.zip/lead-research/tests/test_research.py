import sys
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import research


class ResearchTests(unittest.TestCase):
    def test_directory_domains_are_not_mistaken_for_official_sites(self):
        self.assertTrue(research.is_directory_or_social("2gis.ru"))
        self.assertTrue(research.is_directory_or_social("maps.yandex.ru"))
        self.assertFalse(research.is_directory_or_social("example-build.ru"))

    def test_social_domains(self):
        self.assertTrue(research.is_social("vk.com"))
        self.assertTrue(research.is_social("t.me"))
        self.assertFalse(research.is_social("example.com"))

    def test_contact_extraction(self):
        data = research.extract_contacts(
            "Телефон +7 (495) 123-45-67, почта info@example.ru, Telegram https://t.me/example_news, VK https://vk.com/example",
            "https://2gis.ru/moscow/example",
        )
        self.assertEqual(data["phone"], "+7 (495) 123-45-67")
        self.assertEqual(data["email"], "info@example.ru")
        self.assertEqual(data["telegram_url"], "https://t.me/example_news")
        self.assertEqual(data["vk_url"], "https://vk.com/example")
        self.assertEqual(data["whatsapp_link"], "https://wa.me/74951234567")

    def test_minsk_query_plan_is_one_query_per_approved_niche(self):
        minsk = [q for q in research.query_plan() if q[0] == "Минск"]
        self.assertEqual(len(minsk), 8)
        self.assertTrue(all(q[1] == "Беларусь" for q in minsk))

    def test_only_major_cities_are_configured(self):
        self.assertIn("Москва", research.RUSSIAN_CITIES)
        self.assertIn("Санкт-Петербург", research.RUSSIAN_CITIES)
        self.assertNotIn("Мозырь", research.RUSSIAN_CITIES)

    def test_dates_are_parsed(self):
        dates = research.extract_dates("Последний отзыв 2026-10-21 и пост от 02.11.2026")
        self.assertIn(date(2026, 10, 21), dates)
        self.assertIn(date(2026, 11, 2), dates)
        relative = research.extract_dates("отзыв 3 дня назад", today=date(2026, 11, 8))
        self.assertIn(date(2026, 11, 5), relative)

    def test_qualified_requires_two_website_checks_recent_activity_and_contact(self):
        c = research.Candidate(name="Тест", city="Москва", country="Россия", niche="Кровля")
        c.website_pass_1 = "not_found_in_search"
        c.website_pass_2 = "not_found_in_search"
        c.activity_status = "recent_public_date_found"
        c.phone = "+7 999 111-22-33"
        self.assertTrue(research.is_qualified(c))
        c.website_pass_2 = "verification_failed"
        self.assertFalse(research.is_qualified(c))

    def test_official_domain_is_detected_for_identity_match(self):
        c = research.Candidate(name="Строй Дом Премиум", city="Москва", country="Россия", niche="Строительство домов")
        found = research.official_domains_in_results(c, [{
            "href": "https://stroydom-premium.example/",
            "title": "Строй Дом Премиум — строительство домов в Москве",
            "body": "Строй Дом Премиум официальный сайт, проекты и контакты",
        }])
        self.assertEqual(found, ["stroydom-premium.example"])


if __name__ == "__main__":
    unittest.main()
